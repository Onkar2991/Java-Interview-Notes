package ConstractorExamples;
class Packeges{
    Packeges(String name){
        System.out.println("Creating Parametrize constructor"+" "  +name);
    }
}
public class Example6P {
    public static void main(String[] args) {
        Packeges P=new Packeges("Sameer");

    }
}
