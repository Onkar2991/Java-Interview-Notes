package ConstractorExamples;
class Number{
    Number(int id,int Nub,String Firstname, String Lastname){
        System.out.println(""+id+" "+Nub+" "+Firstname+" "+Lastname);

    }
}
public class Example10P {
    public static void main(String[] args) {
        Number N=new Number(1,2132123211,"sameer","pote");
    }
}
