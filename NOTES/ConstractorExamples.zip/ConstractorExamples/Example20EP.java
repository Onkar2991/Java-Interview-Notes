package ConstractorExamples;
class Exaple{
    private int num1;
    private int num2;

    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }

    public int getNum2() {
        return num2;
    }
Exaple(){
        if(num1==num2){
            System.out.println("Number is equal:");
        }
        else {
            System.out.println("number is not equal");
        }
}
    public void setNum2(int num2) {
        this.num2 = num2;
    }
}

public class Example20EP {
    public static void main(String[] args) {
        Exaple E=new Exaple();
        E.setNum1(22);
        E.setNum1(2);
        System.out.println(E.getNum1()+""+E.getNum2());

    }
}
