package ConstractorExamples;
class orbit{
    private int NoOfOrbit;
    private String NameOfOrbit;

    public int getNoOfOrbit() {
        return NoOfOrbit;
    }

    public void setNoOfOrbit(int noOfOrbit) {
        NoOfOrbit = noOfOrbit;
    }

    public String getNameOfOrbit() {
        return NameOfOrbit;
    }

    public void setNameOfOrbit(String nameOfOrbit) {
        NameOfOrbit = nameOfOrbit;
    }

    orbit(){
        System.out.println("Find out which orbit is in space");
    }
}
public class Example12 {
    public static void main(String[] args) {

        orbit O=new orbit();
        O.setNoOfOrbit(1);
        O.setNameOfOrbit("Erath Orbit");
        System.out.println(O.getNoOfOrbit()+" "+O.getNameOfOrbit());

    }
}
