package ConstractorExamples;
class Marthon{
    Marthon(int id, String name){
        System.out.println("Creating Marathod id and name "+" "+id+" "+name );

    }
}
public class Examaple7P {
    public static void main(String[] args) {
        Marthon M=new Marthon(1,"Sameer");
    }
}
