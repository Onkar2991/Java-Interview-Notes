package ConstractorExamples;
class Connect{
    Connect(int Firstno,int Secondno){
        System.out.println("Substraction "+(Firstno-Secondno));
        System.out.println("Addition "+(Firstno+Secondno));
        System.out.println("Dividation "+(Firstno/Secondno));
        System.out.println("Multiplication "+(Firstno*Secondno));
    }
}
public class Example11 {
    public static void main(String[] args) {
        Connect C= new Connect(4,8);
        Connect C1= new Connect(18,10);
    }
}
