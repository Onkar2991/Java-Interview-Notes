package ConstractorExamples;
class Default{
    private String name="Sameer";
    Default()
    {
        System.out.println("Creating Default constractor   "   + name);
    }
}
public class Example4 {
    public static void main(String[] args) {
        Default D = new Default();

    }
}
