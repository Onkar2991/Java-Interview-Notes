package ConstractorExamples;
class college{
    private int NoOfClass;
    private int NoOfDepartment;
    private String DepartmentName;

    public int getNoOfClass() {
        return NoOfClass;
    }

    public void setNoOfClass(int noOfClass) {
        NoOfClass = noOfClass;
    }

    public int getNoOfDepartment() {
        return NoOfDepartment;
    }

    public void setNoOfDepartment(int noOfDepartment) {
        NoOfDepartment = noOfDepartment;
    }

    public String getDepartmentName() {
        return DepartmentName;
    }

    public void setDepartmentName(String departmentName) {
        DepartmentName = departmentName;
    }

    college(){

        System.out.println("College has different classes");
    }
}
public class Example15E {
    public static void main(String[] args) {
        college C=new college();
        C.setNoOfDepartment(3);
        C.setNoOfClass(5);
        C.setDepartmentName("BCA,MCA,BBA");
        System.out.println(C.getNoOfDepartment()+"  "+C.getNoOfClass()+"   "+C.getDepartmentName());
    }
}
