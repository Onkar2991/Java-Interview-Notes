package ConstractorExamples;
class Animal{
    private String Dog;
    private String Cat;

    public String getDog() {
        return Dog;
    }

    public void setDog(String dog) {
        Dog = dog;
    }

    public String getCat() {
        return Cat;
    }

    public void setCat(String cat) {
        Cat = cat;
    }
    Animal(){
        System.out.println("Having a pet in haouse :");
    }
}
public class Example18EP {
    public static void main(String[] args) {
        Animal A= new Animal();
        A.setCat("marry");
        A.setDog("Nick");
        System.out.println(A.getCat()+A.getDog());

    }
}
