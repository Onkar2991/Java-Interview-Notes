package ConstractorExamples;
class ChessMatch{
    ChessMatch(int id,int age,String name){
        System.out.println("Creating Chess matches competitor details"+"  "+id+" "+age+"  "+name);
    }
}
public class Example8P {
    public static void main(String[] args) {
        ChessMatch CM=new ChessMatch(1,24,"Sameer");
        ChessMatch CM1=new ChessMatch(2,24,"Soham");
        ChessMatch CM2=new ChessMatch(3,24,"Shubham");
        ChessMatch CM3=new ChessMatch(4,24,"Rushi");
        ChessMatch CM4=new ChessMatch(5,24,"Pradeep");

    }
}
