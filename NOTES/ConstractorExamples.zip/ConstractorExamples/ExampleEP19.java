package ConstractorExamples;
class Logic{
    private int numbers;
    private String latters;

    public int getNumbers() {
        return numbers;
    }

    public void setNumbers(int numbers) {
        this.numbers = numbers;
    }

    public String getLatters() {
        return latters;
    }

    public void setLatters(String latters) {
        this.latters = latters;
    }

    Logic(int numbers, String latters){

    }
}
public class ExampleEP19 {
    public static void main(String[] args) {
        Logic L = new Logic(21,"Examples");
        L.setLatters("Examples");
        L.setNumbers(21);
        System.out.println(L.getLatters()+" "+L.getNumbers());

    }
}
