package ConstractorExamples;


class Construct{
    int salary;
    String name;
    Construct(){
        System.out.println("This is Construct class Default constructor ");
    }

    Construct(int salary, String name){
        this.salary = salary;
        this.name = name;
        System.out.println("This is Construct class Parameterized constructor ");
    }
} // 8 29    8 14  23  29    8 29   8 23 30    8/23   14/23/30

public class Const extends Construct{
    String firstName;     String lastName;     int age;
    Const(){
        //call to super class default constructor
        super(10, "Java");
        System.out.println("This is ConstructorChainingProgram class Default constructor ");
    }
    Const(String fName, String lName, int age){
        this();
        this.firstName = fName;
        this.lastName = lName;
        this.age = age;
        System.out.println("This is ConstructorChainingProgram class Parameterized constructor ");
    }
    public static void main(String[] args) {
        Const obj = new Const("Test","Java", 123);
    }
}