package ConstractorExamples;
class Univercity{
    private int number;
    private String name;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    Univercity(int number, String name){
        System.out.println("Find out which univerty you can enter");
        this.number=number;
        this.name=name;
    }
}
public class Example16PE {
    public static void main(String[] args) {
        Univercity U =new Univercity(1,"Pune Univercity");
                U.setNumber(   1);
        U.setName("Pune ");
        System.out.println(U.getNumber()+"  "+U.getName());

    }
}
