package ConstractorExamples;
class Student{
    int rollno;
    String name;

    public int getRollno() {
        return rollno;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    Student(){
        System.out.println(" Example of student :");

    }
}
public class Example14E {
    public static void main(String[] args) {
Student S =new Student();
S.setName("Sameer");
S.setRollno(1);
        System.out.println(S.getName()+"  "+S.getRollno());
    }
}
