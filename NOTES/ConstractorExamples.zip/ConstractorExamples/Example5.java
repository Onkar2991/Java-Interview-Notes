package ConstractorExamples;
class Build{
   private String Firstname ="Sameer";
  private String Lastname ="Pote";

    public String getFirstname() {
        return Firstname;
    }

    public void setFirstname(String firstname) {
        Firstname = firstname;
    }

    public String getLastname() {
        return Lastname;
    }

    public void setLastname(String lastname) {
        Lastname = lastname;
    }

    Build(){
        System.out.println("My full name is "+Firstname  +" "+ Lastname);
    }
}
public class Example5 {
    public static void main(String[] args) {
        Build B= new Build();
        B.setFirstname("Sameer");
        B.setLastname("Pote");
        System.out.println(B.getFirstname()+B.getLastname());



    }
}
