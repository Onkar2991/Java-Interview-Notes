package ConstractorExamples;

class para{
    para(int id,int phon,String name){
        System.out.println(" "+id +" "+phon+" "+name);

    }
}
public class Example9P {
    public static void main(String[] args) {
        para P=new para(1,1234567890,"sameer");
    }
}
