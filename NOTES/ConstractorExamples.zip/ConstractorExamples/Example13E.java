package ConstractorExamples;
class Basic{
    private int id;
    private int mobile;
    private String Name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMobile() {
        return mobile;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    Basic(){
        System.out.println("Enter Basic Detaisl : ");

    }
    void show(){
        System.out.println("Xyz");
    }

}
public class Example13E {
    public static void main(String[] args) {
        Basic B=new Basic();
        B.show();
        B.setId(1);
        B.setName("Shubham");
       B.setMobile(1234567890);
        System.out.println(B.getId());
        System.out.println(B.getName());
        System.out.println(B.getMobile());
       System.out.println(B.getId()+"   "+B.getName()+"  "+B.getMobile());
    }
}
