package ConstractorExamples;
class salary{
    private int salary;
    private String name;

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    salary(int salary,String name){
        this.name="xyz";
        this.salary=salary;
        System.out.println("Example of salary");

    }

}

public class Example17EP {
    public static void main(String[] args)
    {salary S= new salary(12321,"xyz");
S.setName("sameer");
S.setSalary(24245);
        System.out.println(S.getName()+S.getSalary());

    }
}
