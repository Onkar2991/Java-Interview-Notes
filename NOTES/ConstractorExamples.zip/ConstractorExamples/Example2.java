package ConstractorExamples;
class Matrix{

    Matrix(){
        System.out.println("Example Of defaule Constraction with method");

    }
    void run(){
        System.out.println("Example of Constraction class with Methgod");
    }
}
public class Example2 {

    public static void main(String[] args) {
        Matrix MA= new Matrix();
        MA.run();
    }
}
