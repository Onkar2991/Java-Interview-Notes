package ConstractorExamples;
class AAA{
    AAA(){
        System.out.println("Creating Constraction Class ");
    }
}
public class Example3 {
    public static void main(String[] args) {
        AAA A= new AAA();
    }
}
