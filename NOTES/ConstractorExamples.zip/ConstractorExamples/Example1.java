package ConstractorExamples;

 class Meat{
     Meat(){
         System.out.println("Example of Default Constractor");

    }
}

public class Example1 {
    public static void main(String[] args) {
Meat M = new Meat();

    }
}
